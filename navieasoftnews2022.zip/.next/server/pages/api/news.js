"use strict";
(() => {
var exports = {};
exports.id = 801;
exports.ids = [801];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 3711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "config": () => (/* binding */ config),
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/server/errorhandler.js
var errorhandler = __webpack_require__(6284);
// EXTERNAL MODULE: ./services/server/multer.js
var multer = __webpack_require__(5882);
// EXTERNAL MODULE: ./services/server/user/user.js
var user = __webpack_require__(6791);
// EXTERNAL MODULE: ./services/server/common.js
var common = __webpack_require__(5440);
;// CONCATENATED MODULE: ./services/server/news/news.js




async function postNews(req, res) {
    try {
        const { error  } = await (0,multer/* multipleBodyParser */.L)(req, res, "assets", [
            {
                name: "image",
                maxCount: 1
            }, 
        ]);
        if (error) throw {
            message: "Error occured when file uploading"
        };
        //user varify;
        if (!req.body.user_id) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.user_id);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        req.body.image = req.files.image[0].filename;
        req.body.created_at = new Date();
        const sql = "INSERT INTO news SET ?";
        const result = await (0,common/* postDocument */.UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "News added successfully"
            });
        } else res.send({
            message: "Unable to add, try again"
        });
    } catch (err) {
        (0,common/* deleteImage */.ao)(req.files.image[0].filename);
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function getNews(req, res) {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const page = parseInt(req.query.page || 0) * limit;
        let result;
        if (req.query.multiple) {
            //sent multiple new by id;
            const id = req.query.id.replaceAll("|", ",");
            const sql = `SELECT * FROM news WHERE id IN (${id})`;
            result = await (0,common/* queryDocument */.zx)(sql);
        } else if (req.query.id) {
            //sent single news;
            const newssql = `SELECT news.*, c.name as category_name FROM news INNER JOIN category as c ON news.category_id = c.id  WHERE news.id = '${req.query.id}'`;
            const news = await (0,common/* queryDocument */.zx)(newssql);
            if (news.length) {
                const commentsql = `SELECT * FROM comments WHERE news_id = ${news[0].id}`;
                const comments = await (0,common/* queryDocument */.zx)(commentsql);
                result = {
                    ...news[0],
                    comments
                };
            }
        } else {
            //sent all news
            const sql1 = `SELECT news.*, c.name as category_name FROM news INNER JOIN category as c ON c.id = news.category_id ORDER BY created_at DESC LIMIT ${page}, ${limit}`;
            result = await (0,common/* queryDocument */.zx)(sql1);
        }
        res.send(result);
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status || 500
        });
    }
}
async function updateNews(req, res) {
    try {
        const { error  } = await (0,multer/* multipleBodyParser */.L)(req, res, "assets", [
            {
                name: "image",
                maxCount: 1
            }, 
        ]);
        if (error) throw {
            message: error || "Error occured when file uploading"
        };
        //user varify;
        if (!req.body.user_id) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.user_id);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        if (req.files.image) {
            req.body.image = req.files.image[0].filename;
        }
        const existedImg = req.body.existedImg;
        delete req.body.existedImg;
        let data = "";
        Object.entries(req.body).map(([key, value])=>{
            if (data) {
                data += `, ${key} = "${value}"`;
            } else data += `${key} = "${value}"`;
        });
        const sql = `UPDATE news SET ${data} WHERE id = '${req.query.id}'`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            if (existedImg) (0,common/* deleteImage */.ao)(existedImg);
            res.send({
                message: "Updated successfully"
            });
        } else res.send({
            message: "Unable to add, try again"
        });
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function deleteNews(req, res) {
    try {
        const { error  } = await (0,multer/* multipleBodyParser */.L)(req, res, "", []);
        if (error) throw {
            message: error || "Internal server error"
        };
        //user varify;
        if (!req.body.user_id) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.user_id);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        //delete data from db;
        const sql = `DELETE FROM news WHERE id = '${req.query.id}'`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            (0,common/* deleteImage */.ao)(req.body.image);
            res.send({
                message: "News successfully deleted"
            });
        } else throw {
            message: "Unable to delete, try again"
        };
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}

;// CONCATENATED MODULE: ./pages/api/news/index.js

const config = {
    api: {
        bodyParser: false
    }
};
async function handler(req, res) {
    switch(req.method){
        case "GET":
            getNews(req, res);
            break;
        case "POST":
            postNews(req, res);
            break;
        case "PUT":
            updateNews(req, res);
            break;
        case "DELETE":
            deleteNews(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [440,791], () => (__webpack_exec__(3711)));
module.exports = __webpack_exports__;

})();