"use strict";
(() => {
var exports = {};
exports.id = 912;
exports.ids = [912];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 9773:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/server/common.js
var common = __webpack_require__(5440);
// EXTERNAL MODULE: ./services/server/errorhandler.js
var errorhandler = __webpack_require__(6284);
// EXTERNAL MODULE: ./services/server/user/user.js
var user = __webpack_require__(6791);
;// CONCATENATED MODULE: ./services/server/menus/subCategory.js



async function postSubCategoryMenus(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId;
        const sql = `SELECT id FROM sub_category WHERE name = '${req.body.name}'`;
        const isExist = await (0,common/* queryDocument */.zx)(sql);
        if (isExist.length) {
            res.send(409).send({
                message: "Already added the sub category"
            });
            return;
        }
        const query = `INSERT INTO sub_category SET ?`;
        const result = await (0,common/* postDocument */.UZ)(query, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Sub Category menu added successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to add, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function deleteSubCategoryMenu(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId;
        const sql = `DELETE FROM sub_category WHERE ID = ${req.body.id}`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Sub Category menu deleted successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to delete, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}

;// CONCATENATED MODULE: ./pages/api/menus/subcategory.js

async function handler(req, res) {
    switch(req.method){
        case "POST":
            postSubCategoryMenus(req, res);
            break;
        case "DELETE":
            deleteSubCategoryMenu(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [440,791], () => (__webpack_exec__(9773)));
module.exports = __webpack_exports__;

})();