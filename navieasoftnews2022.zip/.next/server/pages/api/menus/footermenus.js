"use strict";
(() => {
var exports = {};
exports.id = 839;
exports.ids = [839];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 6277:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/server/common.js
var common = __webpack_require__(5440);
// EXTERNAL MODULE: ./services/server/errorhandler.js
var errorhandler = __webpack_require__(6284);
// EXTERNAL MODULE: ./services/server/user/user.js
var user = __webpack_require__(6791);
;// CONCATENATED MODULE: ./services/server/menus/footerMenus.js



async function getFooterMenus(req, res) {
    try {
        const result = {};
        const data = await (0,common/* queryDocument */.zx)("SELECT * FROM footer_menu");
        result.news = data.filter((item)=>item.column_number === 1);
        result.opinion = data.filter((item)=>item.column_number === 2);
        result.arts = data.filter((item)=>item.column_number === 3);
        result.living = data.filter((item)=>item.column_number === 4);
        result.more = data.filter((item)=>item.column_number === 5);
        result.social = data.filter((item)=>item.column_number === 6);
        res.send(result);
    } catch (error) {
        (0,errorhandler/* errorHandler */.P)(res);
    }
}
async function postFooterMenus(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId;
        const sql = `SELECT id FROM footer_menu WHERE name = '${req.body.name}' AND column_number = '${req.body.collumn}'`;
        const isExist = await (0,common/* queryDocument */.zx)(sql);
        if (isExist.length) {
            res.status(409).send({
                message: "Already added menu"
            });
            return;
        }
        const query = `INSERT INTO footer_menu SET name = '${req.body.name}', column_number = '${req.body.collumn}'`;
        const result = await (0,common/* queryDocument */.zx)(query);
        if (result.insertId > 0) {
            res.status(200).send({
                message: "Menu added successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to add, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function deleteFooterMenus(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId;
        const sql = `DELETE FROM footer_menu WHERE name = '${req.body.name}' AND column_number = '${req.body.collumn}'`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Menu deleted successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to delete, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}

;// CONCATENATED MODULE: ./pages/api/menus/footermenus.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getFooterMenus(req, res);
            break;
        case "POST":
            postFooterMenus(req, res);
            break;
        case "DELETE":
            deleteFooterMenus(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [440,791], () => (__webpack_exec__(6277)));
module.exports = __webpack_exports__;

})();