"use strict";
(() => {
var exports = {};
exports.id = 879;
exports.ids = [879];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 8447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/server/errorhandler.js
var errorhandler = __webpack_require__(6284);
// EXTERNAL MODULE: ./services/server/user/user.js
var user = __webpack_require__(6791);
// EXTERNAL MODULE: ./services/server/common.js
var common = __webpack_require__(5440);
;// CONCATENATED MODULE: ./services/server/menus/categoryMenus.js



async function getCategoryMenus(req, res) {
    try {
        const result = await (0,common/* queryDocument */.zx)("SELECT * FROM category");
        result.forEach(async (category, i, arr)=>{
            const subs = await (0,common/* queryDocument */.zx)(`SELECT * FROM sub_category WHERE category_id = ${category.id}`);
            result[i].subs = subs;
            if (arr.length - 1 === i) {
                res.send(result);
            }
        });
    } catch (error) {
        (0,errorhandler/* errorHandler */.P)(res, error);
    }
}
async function postCategoryMenus(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        // const isExist = await categoryMenus.findOne({ name: req.body.name });
        const sql = `SELECT id FROM category WHERE name = '${req.body.name}'`;
        const isExist = await (0,common/* queryDocument */.zx)(sql);
        if (isExist.length) {
            res.status(409).send({
                message: "Already added the category"
            });
            return;
        }
        delete req.body.userId;
        const query = "INSERT INTO category SET ?";
        const result = await (0,common/* postDocument */.UZ)(query, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Menu added successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to add, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function updateCategoryMenus(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId;
        const sql = `UPDATE category SET name ='${req.body.name}'  WHERE id = '${req.body.id}'`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Category menu updated successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to update, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status || 500
        });
    }
}
async function deleteCategoryMenu(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId;
        const sql = `DELETE FROM category WHERE id = '${req.body.id}'`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Category menu delete successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to delete, Try again."
            });
        }
    } catch (error) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: error.message,
            status: error.status
        });
    }
}

;// CONCATENATED MODULE: ./pages/api/menus/index.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getCategoryMenus(req, res);
            break;
        case "POST":
            postCategoryMenus(req, res);
            break;
        case "PUT":
            updateCategoryMenus(req, res);
            break;
        case "DELETE":
            deleteCategoryMenu(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [440,791], () => (__webpack_exec__(8447)));
module.exports = __webpack_exports__;

})();