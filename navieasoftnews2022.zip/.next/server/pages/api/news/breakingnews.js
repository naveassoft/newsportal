"use strict";
(() => {
var exports = {};
exports.id = 568;
exports.ids = [568];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 1738:
/***/ ((module) => {

module.exports = require("multer");

/***/ }),

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 2303:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/server/errorhandler.js
var errorhandler = __webpack_require__(6284);
// EXTERNAL MODULE: ./services/server/user/user.js
var user = __webpack_require__(6791);
// EXTERNAL MODULE: ./services/server/common.js
var common = __webpack_require__(5440);
;// CONCATENATED MODULE: ./services/server/news/breakingnews.js



async function getBreakingNews(req, res) {
    try {
        const result = await (0,common/* queryDocument */.zx)("SELECT * FROM breaking_news");
        res.send(result);
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function postBreakingNews(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.userId;
        const sql = `SELECT id FROM breaking_news WHERE value = '${req.body.value}'`;
        const isExist = await (0,common/* queryDocument */.zx)(sql);
        if (isExist.length) {
            res.status(409).send({
                message: "Already added menu"
            });
            return;
        }
        const query = `INSERT INTO breaking_news SET value = '${req.body.value}'`;
        const result = await (0,common/* queryDocument */.zx)(query);
        if (result.insertId > 0) {
            res.send({
                message: "Breaking news added successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to add, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function deleteBreakingNews(req, res) {
    try {
        if (!req.body.userId) throw {
            message: "user unathenticated!"
        };
        const varify = await (0,user/* userVarification */.yv)(req.body.userId);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        console.log(req.body);
        const sql = `DELETE FROM breaking_news WHERE id = '${req.body.id}'`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (result.affectedRows > 0) {
            res.send({
                message: "Breaking news deleted successfully"
            });
        } else {
            res.status(424).send({
                message: "Unable to delete, Try again."
            });
        }
    } catch (err) {
        (0,errorhandler/* errorHandler */.P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}

;// CONCATENATED MODULE: ./pages/api/news/breakingnews.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getBreakingNews(req, res);
            break;
        case "POST":
            postBreakingNews(req, res);
            break;
        case "DELETE":
            deleteBreakingNews(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [440,791], () => (__webpack_exec__(2303)));
module.exports = __webpack_exports__;

})();