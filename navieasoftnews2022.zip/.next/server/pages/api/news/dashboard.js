"use strict";
(() => {
var exports = {};
exports.id = 987;
exports.ids = [987];
exports.modules = {

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 4044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _services_server_common__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5440);
/* harmony import */ var _services_server_errorhandler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6284);


async function handler(req, res) {
    switch(req.method){
        case "GET":
            handleDashboard(res);
            break;
        case "POST":
            postCommentOnNews(req, res);
            break;
        case "PUT":
            updateNewsViews(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}
function getAllDates() {
    const date = new Date();
    const today = date.toISOString().slice(0, 10);
    const yesterday = new Date(date.valueOf() - 1000 * 60 * 60 * 24).toISOString().slice(0, 10);
    const beforeYesterday = new Date(date.valueOf() - 1000 * 60 * 60 * 48).toISOString().slice(0, 10);
    const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1).toISOString().slice(0, 10);
    const previousMonth = new Date(date.getFullYear(), date.getMonth() - 1, 1).toISOString().slice(0, 10);
    const firstDayOfYear = new Date(date.getFullYear(), 0, 1).toISOString().slice(0, 10);
    const previousYear = new Date(date.getFullYear() - 1, 0, 1).toISOString().slice(0, 10);
    return {
        today,
        yesterday,
        beforeYesterday,
        firstDayOfMonth,
        previousMonth,
        firstDayOfYear,
        previousYear
    };
}
async function getPostReport() {
    const { today , yesterday , beforeYesterday , firstDayOfMonth , previousMonth , firstDayOfYear , previousYear ,  } = getAllDates();
    const todaysql = `SELECT id, created_at FROM news WHERE created_at >= '${yesterday}' AND created_at <= '${today}'`;
    const todaysNews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(todaysql);
    const yestersql = `SELECT id FROM news WHERE created_at >= '${beforeYesterday}' AND created_at <= '${yesterday}'`;
    const yesterNews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(yestersql);
    const thismonthsql = `SELECT id FROM news WHERE created_at >= '${firstDayOfMonth}' AND created_at <= '${today}'`;
    const thisMonthNews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(thismonthsql);
    const previousmonthsql = `SELECT id FROM news WHERE created_at >= '${previousMonth}' AND created_at <= '${firstDayOfMonth}'`;
    const previousMonthNews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(previousmonthsql);
    const thisYearsql = `SELECT id FROM news WHERE created_at >= '${firstDayOfYear}' AND created_at <= '${today}'`;
    const thisYearNews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(thisYearsql);
    const previousYearsql = `SELECT id FROM news WHERE created_at >= '${previousYear}' AND created_at <= '${firstDayOfYear}'`;
    const previousYearNews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(previousYearsql);
    return [
        {
            name: "Today's Post",
            count: todaysNews.length,
            grouth: todaysNews.length - yesterNews.length || 1 / yesterNews.length || 0 * 100
        },
        {
            name: "This Month's Post",
            count: thisMonthNews.length,
            grouth: thisMonthNews.length - previousMonthNews.length || 1 / previousMonthNews.length || 0 * 100
        },
        {
            name: "This year's Post",
            count: thisYearNews.length,
            grouth: thisYearNews.length - previousYearNews.length || 1 / previousYearNews.length || 0 * 100
        }, 
    ];
}
async function getVisitorReport() {
    const { today , yesterday , beforeYesterday , firstDayOfMonth , previousMonth , firstDayOfYear , previousYear ,  } = getAllDates();
    const todaysql = `SELECT id FROM visitors WHERE date >= '${yesterday}' AND date <= '${today}'`;
    const todaysViews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(todaysql);
    const yestersql = `SELECT id FROM visitors WHERE date >= '${beforeYesterday}' AND date <= '${yesterday}'`;
    const yesterViews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(yestersql);
    const thismonthsql = `SELECT id FROM visitors WHERE date >= '${firstDayOfMonth}' AND date <= '${today}'`;
    const thisMonthViews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(thismonthsql);
    const previousmonthsql = `SELECT id FROM visitors WHERE date >= '${previousMonth}' AND date <= '${firstDayOfMonth}'`;
    const previousMonthViews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(previousmonthsql);
    const thisYearsql = `SELECT id FROM visitors WHERE date >= '${firstDayOfYear}' AND date <= '${today}'`;
    const thisYearViews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(thisYearsql);
    const previousYearsql = `SELECT id FROM visitors WHERE date >= '${previousYear}' AND date <= '${firstDayOfYear}'`;
    const previousYearViews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(previousYearsql);
    return [
        {
            name: "Today's Views",
            count: todaysViews.length,
            grouth: todaysViews.length - yesterViews.length || 1 / yesterViews.length || 0 * 100
        },
        {
            name: "This Month's Views",
            count: thisMonthViews.length,
            grouth: thisMonthViews.length - previousMonthViews.length || 1 / previousMonthViews.length || 0 * 100
        },
        {
            name: "This year's Post",
            count: thisYearViews.length,
            grouth: thisYearViews.length - previousYearViews.length || 1 / previousYearViews.length || 0 * 100
        }, 
    ];
}
async function handleDashboard(res) {
    try {
        const sql = "SELECT news.headline, news.date, news.editor_name, category.name as category_name, s.name as sub_category_name FROM news INNER JOIN category ON news.category_id = category.id INNER JOIN sub_category as s ON news.sub_category_id = s.id ORDER BY created_at LIMIT 10";
        const someNews = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(sql);
        const postReport = await getPostReport();
        const viewerReport = await getVisitorReport();
        res.send({
            someNews,
            postReport,
            viewerReport
        });
    } catch (err) {
        (0,_services_server_errorhandler__WEBPACK_IMPORTED_MODULE_1__/* .errorHandler */ .P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function updateNewsViews(req, res) {
    try {
        //update news views;
        if (req.query.news) {
            req.body.date = new Date().toISOString().slice(0, 10);
            const isExistsql = `SELECT id FROM news_viewers WHERE news_id = '${req.body.news_id}' AND ipAdress = '${req.body.ipAdress}' AND date = '${req.body.date}'`;
            const isExist = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(isExistsql);
            if (isExist.length) throw {
                message: "already added",
                status: 200
            };
            const result = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .postDocument */ .UZ)("INSERT INTO news_viewers SET ?", req.body);
            if (result.insertId > 0) {
                res.send({
                    message: "Added"
                });
            } else {
                res.send({
                    message: "Unable to add"
                });
            }
        } else {
            req.body.date = new Date().toISOString().slice(0, 10);
            const existsql = `SELECT id FROM visitors WHERE ipAdress = '${req.body.ipAdress}' AND date = '${req.body.date}'`;
            const existed = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .queryDocument */ .zx)(existsql);
            if (existed.length) throw {
                message: "already added",
                status: 200
            };
            const result1 = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .postDocument */ .UZ)("INSERT INTO visitors SET ?", req.body);
            if (result1.insertId > 0) {
                res.send({
                    message: "Added"
                });
            } else {
                throw {
                    message: "Unable to Added"
                };
            }
        }
    } catch (err) {
        (0,_services_server_errorhandler__WEBPACK_IMPORTED_MODULE_1__/* .errorHandler */ .P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function postCommentOnNews(req, res) {
    try {
        const sql = "INSERT INTO comments SET ?";
        const result = await (0,_services_server_common__WEBPACK_IMPORTED_MODULE_0__/* .postDocument */ .UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Thank you for staying us."
            });
        } else throw {
            message: "unable to post comment, please try again"
        };
    } catch (error) {
        (0,_services_server_errorhandler__WEBPACK_IMPORTED_MODULE_1__/* .errorHandler */ .P)(res, {
            msg: error?.message,
            status: error?.status
        });
    }
}


/***/ }),

/***/ 6284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ errorHandler)
/* harmony export */ });
function errorHandler(res, { msg , status  } = {}) {
    res.status(status || 500).send({
        message: msg || "Serverside error"
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [440], () => (__webpack_exec__(4044)));
module.exports = __webpack_exports__;

})();