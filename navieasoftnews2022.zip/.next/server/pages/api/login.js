"use strict";
(() => {
var exports = {};
exports.id = 994;
exports.ids = [994];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 2744:
/***/ ((module) => {

module.exports = require("mysql");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 7147:
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ 1017:
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ 31:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ./services/server/common.js
var common = __webpack_require__(5440);
// EXTERNAL MODULE: external "bcrypt"
var external_bcrypt_ = __webpack_require__(7096);
var external_bcrypt_default = /*#__PURE__*/__webpack_require__.n(external_bcrypt_);
;// CONCATENATED MODULE: external "jsonwebtoken"
const external_jsonwebtoken_namespaceObject = require("jsonwebtoken");
var external_jsonwebtoken_default = /*#__PURE__*/__webpack_require__.n(external_jsonwebtoken_namespaceObject);
;// CONCATENATED MODULE: ./services/server/login.js



async function getUser(req, res) {
    try {
        //send email for forget password;
        if (req.query.forgotPassword) {
            sendForgotPasswordLink(req, res);
        } else if (req.query.varifypasswordToken) {
            varifypasswordToken(req, res);
        } else if (req.query.varifyEmail) {
            varifyEmail(req, res);
        } else {
            if (!req.query.token) {
                return errorHandler(res, {
                    message: "Unauthenticated",
                    status: 401
                });
            }
            const varify = external_jsonwebtoken_default().verify(req.query.token, process.env.JWT_SECRET);
            if (varify) {
                const sql = `SELECT * FROM user WHERE id = '${varify.id}' AND email = '${varify.email}'`;
                const user = await (0,common/* queryDocument */.zx)(sql);
                delete user[0].password;
                const token = external_jsonwebtoken_default().sign({
                    ...user[0]
                }, process.env.JWT_SECRET, {
                    expiresIn: `${varify.user_role !== "user" ? "3d" : "5h"}`
                });
                res.send({
                    user: user[0],
                    token
                });
            } else throw {
                message: "Unauthenticated",
                status: 401
            };
        }
    } catch (error) {
        res.status(500).send({
            message: error.message
        });
    }
}
async function loginUser(req, res) {
    try {
        //social media login;
        if (req.query.socialLogin) {
            const sql = `SELECT * FROM user WHERE email = '${req.body.email}'`;
            const result = await (0,common/* queryDocument */.zx)(sql);
            if (!result.length) {
                if ("5994471abb01112afcc18159f6cc74b4f511b99806da59b" !== req.body.password) {
                    throw {
                        message: "Forbiden",
                        status: 403
                    };
                }
                const hashed = await external_bcrypt_default().hash(req.body.password, 10);
                req.body.password = hashed;
                const sql1 = "INSERT INTO user ?";
                const result1 = await (0,common/* queryDocument */.zx)(sql1, req.body);
                delete result1[0].password;
                const token = external_jsonwebtoken_default().sign({
                    ...result1[0]
                }, process.env.JWT_SECRET, {
                    expiresIn: "3d"
                });
                res.send({
                    user: result1[0],
                    token
                });
            } else {
                const sql2 = `SELECT * FROM user WHERE email = '${req.body.email}'`;
                const result2 = await (0,common/* queryDocument */.zx)(sql2);
                delete result2[0].password;
                const token1 = external_jsonwebtoken_default().sign({
                    ...result2[0]
                }, process.env.JWT_SECRET, {
                    expiresIn: `${result2[0].user_role !== "user" ? "3d" : "5h"}`
                });
                res.send({
                    user: result2[0],
                    token: token1
                });
            }
        } else {
            const sql3 = `SELECT * FROM user WHERE email = '${req.body.email}'`;
            const result3 = await (0,common/* queryDocument */.zx)(sql3);
            if (!result3.length) throw {
                message: "No user found",
                status: 404
            };
            else {
                sendUserInfo(req, res, result3);
            }
        }
    } catch (error) {
        res.status(500).send({
            message: error.message
        });
    }
}
async function signUpUser(req, res) {
    try {
        //update user password;
        if (req.query.updateuser) {
            const sql = `SELECT * FROM user WHERE id = '${req.body.id}' AND email = '${req.body.email}'`;
            const result = await (0,common/* queryDocument */.zx)(sql);
            if (!result.length) throw {
                message: "There was an error"
            };
            const hashed = await external_bcrypt_default().hash(req.body.password, 10);
            const query = `UPDATE user SET password='${hashed}' WHERE id=${req.body.id}`;
            const user = await (0,common/* queryDocument */.zx)(query);
            console.log(user);
            if (user.changedRows > 0) {
                const sql1 = `SELECT * FROM user WHERE id = '${req.body.id}'`;
                const result1 = await (0,common/* queryDocument */.zx)(sql1);
                const token = external_jsonwebtoken_default().sign({
                    ...result1[0]
                }, process.env.JWT_SECRET, {
                    expiresIn: `${result1[0].user_role !== "user" ? "3d" : "5h"}`
                });
                res.send({
                    message: "Your password updated successfully",
                    token
                });
            } else res.status(500).send({
                message: "There was an error"
            });
        } else {
            const sql2 = `SELECT * FROM user WHERE email = '${req.body.email}'`;
            const result2 = await (0,common/* queryDocument */.zx)(sql2);
            if (result2.length) {
                return res.status(409).send({
                    message: "User already exist"
                });
            } else {
                const token1 = external_jsonwebtoken_default().sign(req.body, process.env.JWT_SECRET, {
                    expiresIn: "1h"
                });
                const options = (0,common/* varifyEmailOpt */.hE)(req.body.email, token1);
                const email = await common/* mailer.sendMail */.Ei.sendMail(options);
                if (email.messageId) {
                    res.send({
                        message: "An email sent to your email, please check"
                    });
                } else throw {
                    message: "There was an error"
                };
            }
        }
    } catch (error) {
        res.status(500).send({
            message: error.message
        });
    }
}
async function sendForgotPasswordLink(req, res) {
    try {
        const sql = `SELECT * FROM user WHERE email = '${req.query.forgotPassword}'`;
        const result = await (0,common/* queryDocument */.zx)(sql);
        if (!result.length) {
            res.status(404).send({
                message: "No user found"
            });
            return;
        }
        delete result[0].password;
        const token = external_jsonwebtoken_default().sign({
            ...result[0]
        }, process.env.JWT_SECRET, {
            expiresIn: "1h"
        });
        const options = (0,common/* forgotMailOpt */.FJ)(req.query.forgotPassword, token);
        const email = await common/* mailer.sendMail */.Ei.sendMail(options);
        if (email.messageId) {
            res.send({
                message: "An email sent to your email, please check"
            });
        } else throw {
            message: "There was an error"
        };
    } catch (error) {
        res.status(500).send({
            message: error.message
        });
    }
}
async function varifyEmail(req, res) {
    try {
        external_jsonwebtoken_default().verify(req.query.varifyEmail, process.env.JWT_SECRET, async (err, result)=>{
            if (err) {
                res.status(401).send({
                    message: "Varification faild"
                });
            } else {
                delete result.iat;
                delete result.exp;
                const hashedPassword = await external_bcrypt_default().hash(result.password, 10);
                result.password = hashedPassword;
                const sql = "INSERT INTO user SET ?";
                const user = await (0,common/* postDocument */.UZ)(sql, result);
                if (user.insertId > 0) {
                    const sql1 = `SELECT * FROM user WHERE id = '${user.insertId}'`;
                    const result1 = await (0,common/* queryDocument */.zx)(sql1);
                    delete result1[0].password;
                    const token = external_jsonwebtoken_default().sign({
                        ...result1[0]
                    }, process.env.JWT_SECRET, {
                        expiresIn: "3d"
                    });
                    res.send({
                        user: result1[0],
                        token
                    });
                } else res.status(500).send({
                    message: "Unable to Added"
                });
            }
        });
    } catch (error) {
        res.status(500).send({
            message: "There was an error"
        });
    }
}
function varifypasswordToken(req, res) {
    external_jsonwebtoken_default().verify(req.query.varifypasswordToken, process.env.JWT_SECRET, (err, result)=>{
        if (err) {
            res.status(401).send({
                message: "Token expired"
            });
        } else {
            delete result.exp;
            delete result.iat;
            res.send(result);
        }
    });
}
async function sendUserInfo(req, res, result) {
    const isRightPassword = await external_bcrypt_default().compare(req.body.password, result[0].password);
    if (!isRightPassword) {
        res.status(401).send({
            message: "Username or password incorrect"
        });
    } else {
        delete result[0].password;
        const token = external_jsonwebtoken_default().sign({
            ...result[0]
        }, process.env.JWT_SECRET, {
            expiresIn: `${result[0].user_role !== "user" ? "3d" : "5h"}`
        });
        res.send({
            user: result[0],
            token
        });
    }
}

;// CONCATENATED MODULE: ./pages/api/login.js

async function handler(req, res) {
    switch(req.method){
        case "GET":
            getUser(req, res);
            break;
        case "POST":
            loginUser(req, res);
            break;
        case "PUT":
            signUpUser(req, res);
            break;
        default:
            res.status(404).send({
                message: "not found"
            });
            break;
    }
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [440], () => (__webpack_exec__(31)));
module.exports = __webpack_exports__;

})();