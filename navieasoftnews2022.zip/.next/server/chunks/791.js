"use strict";
exports.id = 791;
exports.ids = [791];
exports.modules = {

/***/ 6284:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ errorHandler)
/* harmony export */ });
function errorHandler(res, { msg , status  } = {}) {
    res.status(status || 500).send({
        message: msg || "Serverside error"
    });
}


/***/ }),

/***/ 5882:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ multipleBodyParser)
/* harmony export */ });
/* harmony import */ var multer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1738);
/* harmony import */ var multer__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(multer__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_1__);


async function multipleBodyParser(req, res, folder, images) {
    try {
        const MulterConfiq = multer__WEBPACK_IMPORTED_MODULE_0___default()({
            storage: multer__WEBPACK_IMPORTED_MODULE_0___default().diskStorage({
                destination: function(req, file, cb) {
                    cb(null, path__WEBPACK_IMPORTED_MODULE_1___default().join(process.cwd(), "public", folder));
                },
                filename (req, file, cb) {
                    let fileName;
                    const isFavicon = req.files.favicon;
                    if (isFavicon) {
                        fileName = "favicon.ico";
                    } else {
                        fileName = `${file.fieldname}-${Date.now()}${path__WEBPACK_IMPORTED_MODULE_1___default().extname(file.originalname)}`;
                    }
                    cb(null, fileName);
                }
            }),
            fileFilter: (req, file, cb)=>{
                const filetypes = /jpg|jpeg|png|gif/;
                const extname = filetypes.test(path__WEBPACK_IMPORTED_MODULE_1___default().extname(file.originalname).toLowerCase());
                const mimetype = filetypes.test(file.mimetype);
                if (extname && mimetype) {
                    return cb(null, true);
                } else {
                    cb("Unsupported file extension");
                }
            },
            limits: 1000000
        });
        await new Promise((resolve)=>{
            const multer = MulterConfiq.fields(images);
            multer(req, res, resolve);
        });
        return {
            error: false
        };
    } catch (err) {
        return {
            error: err.message
        };
    }
}


/***/ }),

/***/ 6791:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Nq": () => (/* binding */ updateUser),
/* harmony export */   "PR": () => (/* binding */ getUser),
/* harmony export */   "cn": () => (/* binding */ addUser),
/* harmony export */   "pl": () => (/* binding */ deleteuser),
/* harmony export */   "yv": () => (/* binding */ userVarification)
/* harmony export */ });
/* harmony import */ var _errorhandler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6284);
/* harmony import */ var _multer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5882);
/* harmony import */ var _common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5440);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7147);
/* harmony import */ var fs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(fs__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1017);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7096);
/* harmony import */ var bcrypt__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bcrypt__WEBPACK_IMPORTED_MODULE_4__);






async function addUser(req, res) {
    try {
        const { error  } = await (0,_multer__WEBPACK_IMPORTED_MODULE_0__/* .multipleBodyParser */ .L)(req, res, "", []);
        if (error) throw {
            message: "Error occured when file uploading"
        };
        //user varify;
        if (!req.body.user_id) throw {
            message: "user unathenticated!"
        };
        const varify = await userVarification(req.body.user_id);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.user_id; //till;
        const existsql = `SELECT id FROM user WHERE email = '${req.body.email}'`;
        const isExist = await (0,_common__WEBPACK_IMPORTED_MODULE_1__/* .queryDocument */ .zx)(existsql);
        if (isExist.length) throw {
            message: "Already exist",
            status: 409
        };
        const hashed = await bcrypt__WEBPACK_IMPORTED_MODULE_4___default().hash(req.body.password, 10);
        req.body.password = hashed;
        const sql = "INSERT INTO user SET ?";
        const result = await (0,_common__WEBPACK_IMPORTED_MODULE_1__/* .postDocument */ .UZ)(sql, req.body);
        if (result.insertId > 0) {
            res.send({
                message: "Addedd successfully"
            });
        } else throw {
            message: "Unable to add"
        };
    } catch (err) {
        (0,_errorhandler__WEBPACK_IMPORTED_MODULE_5__/* .errorHandler */ .P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function getUser(req, res) {
    try {
        const limit = parseInt(req.query.limit) || 10;
        const page = parseInt(req.query.page || 0) * limit;
        let sql = "";
        if (req.query.filter) {
            sql = `SELECT * FROM user WHERE user_role = '${req.query.filter}' LIMIT ${page}, ${limit}`;
        } else {
            sql = `SELECT * FROM user LIMIT ${page}, ${limit}`;
        }
        const result = await (0,_common__WEBPACK_IMPORTED_MODULE_1__/* .queryDocument */ .zx)(sql);
        res.send(result);
    } catch (err) {
        (0,_errorhandler__WEBPACK_IMPORTED_MODULE_5__/* .errorHandler */ .P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function updateUser(req, res) {
    try {
        const { error  } = await (0,_multer__WEBPACK_IMPORTED_MODULE_0__/* .multipleBodyParser */ .L)(req, res, "", [
            {
                name: "profile",
                maxCount: 1
            }, 
        ]);
        if (error) throw {
            message: "Error occured when file uploading"
        };
        //user varify;
        if (!req.body.user_id) throw {
            message: "user unathenticated!"
        };
        const varify = await userVarification(req.body.user_id);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        delete req.body.user_id; //till;
        if (req.query.profile) {
            let sql = "";
            if (req.files.profile) {
                sql = `UPDATE user SET profile = '${req.files.profile[0].filename}' WHERE id = '${req.body.id}'`;
            } else {
                sql = `UPDATE user SET name = '${req.body.name}' WHERE id = '${req.body.id}'`;
            }
            await (0,_common__WEBPACK_IMPORTED_MODULE_1__/* .queryDocument */ .zx)(sql);
            if (req.body.exist) {
                fs__WEBPACK_IMPORTED_MODULE_2___default().unlinkSync(path__WEBPACK_IMPORTED_MODULE_3___default().join(process.cwd(), "public", req.body.exist));
            }
            res.send({
                message: "Updated successfully"
            });
        } else {
            const sql1 = `UPDATE user SET user_role = '${req.body.user_role}' WHERE id = '${req.body.id}'`;
            await (0,_common__WEBPACK_IMPORTED_MODULE_1__/* .queryDocument */ .zx)(sql1);
            res.send({
                message: "Updated successfully"
            });
        }
    } catch (err) {
        (0,_errorhandler__WEBPACK_IMPORTED_MODULE_5__/* .errorHandler */ .P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function deleteuser(req, res) {
    try {
        const { error  } = await (0,_multer__WEBPACK_IMPORTED_MODULE_0__/* .multipleBodyParser */ .L)(req, res, "", []);
        if (error) throw {
            message: "Error occured when file uploading"
        };
        // user varify;
        if (!req.body.user_id) throw {
            message: "user unathenticated!"
        };
        const varify = await userVarification(req.body.user_id);
        if (!varify) throw {
            message: "user unathenticated!"
        };
        //till;
        const sql = `DELETE FROM user WHERE id = ${req.query.id}`;
        const result = await (0,_common__WEBPACK_IMPORTED_MODULE_1__/* .queryDocument */ .zx)(sql);
        if (result.affectedRows > 0) res.send({
            message: "Deleted successfull"
        });
        else throw {
            message: "unable to delete"
        };
    } catch (err) {
        (0,_errorhandler__WEBPACK_IMPORTED_MODULE_5__/* .errorHandler */ .P)(res, {
            msg: err.message,
            status: err.status
        });
    }
}
async function userVarification(id) {
    return new Promise(async (resolve, reject)=>{
        try {
            const sql = `SELECT id, user_role FROM user WHERE id = '${id}'`;
            const user = await (0,_common__WEBPACK_IMPORTED_MODULE_1__/* .queryDocument */ .zx)(sql);
            if (!user.length || user[0].user_role !== "admin") {
                throw {
                    message: "Forbidden",
                    status: 409
                };
            }
            resolve(user[0]);
        } catch (error) {
            reject(error);
        }
    });
}


/***/ })

};
;