"use strict";
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 6931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_client_common__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9375);
/* harmony import */ var _context_useStore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(980);
/* harmony import */ var _advertizer_SmallAd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9703);
/* eslint-disable @next/next/no-img-element */ 





const CategoryDetailsSideBar = ({ page  })=>{
    const { 0: latestNews , 1: setLatestNews  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: mostreaded , 1: setMostReaded  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: ads , 1: setAds  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { setError  } = (0,_context_useStore__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        (async function() {
            try {
                const latest = await (0,_services_client_common__WEBPACK_IMPORTED_MODULE_5__/* .axios */ .o)("/api/news?page=0");
                const mostreaded = await (0,_services_client_common__WEBPACK_IMPORTED_MODULE_5__/* .axios */ .o)("/api/news/home?mostreaded=true");
                const ads = await (0,_services_client_common__WEBPACK_IMPORTED_MODULE_5__/* .axios */ .o)("/api/settings/ads");
                setLatestNews(latest);
                setMostReaded(mostreaded);
                setAds(ads.other);
            } catch (error) {
                setError(true);
            }
        })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "hidden md:block",
        children: [
            ads && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_advertizer_SmallAd__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                picture: `/ads/${ads?.small[0].image || ""}`,
                link: ads?.small[0].link
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: `some-news ${page === "details" ? "h-[900px]" : "h-[430px]"}`,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                        children: "Latest news:"
                    }),
                    latestNews && latestNews?.map((news)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: `details?id=${news.id}`,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                className: "news",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "object-contain",
                                        src: `/assets/${news.image}`,
                                        alt: ""
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "font-medium col-span-2",
                                        children: news.headline
                                    })
                                ]
                            })
                        }, news.id))
                ]
            }),
            ads && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_advertizer_SmallAd__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                picture: `/ads/${ads?.small[1].image || ""}`,
                link: ads?.small[1].link
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "some-news h-[900px]",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                        children: "Most read:"
                    }),
                    mostreaded && mostreaded?.map((news)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                            href: `details?id=${news.id}`,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                className: "news",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "font-medium col-span-2 pl-2",
                                        children: news.headline
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "object-contain",
                                        src: `/assets/${news.image}`,
                                        alt: ""
                                    })
                                ]
                            })
                        }, news.id))
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CategoryDetailsSideBar);


/***/ }),

/***/ 9375:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ axios)
/* harmony export */ });
async function axios(url, options) {
    return new Promise(async (resolve, reject)=>{
        try {
            const res = await fetch(url, options);
            const result = await res.json();
            if (!res.ok) throw {
                message: result.message
            };
            resolve(result);
        } catch (error) {
            reject(error);
        }
    });
}


/***/ })

};
;