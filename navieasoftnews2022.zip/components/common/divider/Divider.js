import React from "react";

const Divider = () => {
  return (
    <div className='px-5 lg:px-10 space-y-1'>
      <hr />
      <hr />
    </div>
  );
};

export default Divider;
